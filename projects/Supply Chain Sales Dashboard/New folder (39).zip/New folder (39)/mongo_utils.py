from pymongo import MongoClient
import os

# Replace this with your real Mongo URI
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

client = MongoClient(MONGO_URI)
db = client["supply_chain_db"]
collection = db["forecasts"]

def save_forecast(store_id, dept_id, forecast_data):
    document = {
        "store_id": store_id,
        "dept_id": dept_id,
        "forecast": forecast_data
    }
    collection.insert_one(document)
