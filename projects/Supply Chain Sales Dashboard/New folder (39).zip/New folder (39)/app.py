from mongo_utils import save_forecast
from fastapi import FastAPI, Query
from forecast_model import train_prophet
import pandas as pd

app = FastAPI()

@app.get("/")
def root():
    return {"message": "Supply Chain Forecasting API is running"}
@app.get("/forecast")
def get_forecast(store_id: int = Query(...), dept_id: int = Query(...)):
    try:
        forecast = train_prophet(store_id, dept_id)
        forecast_data = forecast.to_dict(orient="records")

        # Save to MongoDB
        save_forecast(store_id, dept_id, forecast_data)

        return {
            "store_id": store_id,
            "dept_id": dept_id,
            "forecast": forecast_data
        }

    except Exception as e:
        return {"error": str(e)}
