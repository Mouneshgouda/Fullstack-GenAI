from forecast_model import train_prophet

forecast = train_prophet(store_id=1, dept_id=1)
print(forecast)
