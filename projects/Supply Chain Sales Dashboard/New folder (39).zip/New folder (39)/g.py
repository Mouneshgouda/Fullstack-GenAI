import streamlit as st
import pandas as pd
import plotly.express as px
from prepare_data import load_and_merge_data
from forecast_model import train_prophet

# Load data
st.set_page_config(layout="wide")
st.title("🛒 Supply Chain Sales Dashboard")

df = load_and_merge_data()
store_ids = df['Store'].unique()
dept_ids = df['Dept'].unique()

# Sidebar
st.sidebar.header("🔍 Filters")
selected_store = st.sidebar.selectbox("Select Store", store_ids)
selected_dept = st.sidebar.selectbox("Select Department", dept_ids)

# Filter data
filtered = df[(df["Store"] == selected_store) & (df["Dept"] == selected_dept)]

st.subheader(f"📈 Weekly Sales for Store {selected_store} - Dept {selected_dept}")
fig = px.line(filtered, x="Date", y="Weekly_Sales", title="Sales Trend")
st.plotly_chart(fig, use_container_width=True)

# Forecast section
st.subheader("🔮 Forecast (Next 90 Days)")

forecast = train_prophet(selected_store, selected_dept)
fig2 = px.line(forecast, x="ds", y="yhat", labels={"ds": "Date", "yhat": "Forecasted Sales"}, title="Forecast")
fig2.add_scatter(x=forecast["ds"], y=forecast["yhat_upper"], mode="lines", name="Upper Bound")
fig2.add_scatter(x=forecast["ds"], y=forecast["yhat_lower"], mode="lines", name="Lower Bound")
st.plotly_chart(fig2, use_container_width=True)

# Extra: Markdown summary
st.subheader("🧾 MarkDown Analysis")
markdown_cols = [col for col in filtered.columns if "MarkDown" in col]
st.bar_chart(filtered[markdown_cols].mean())
