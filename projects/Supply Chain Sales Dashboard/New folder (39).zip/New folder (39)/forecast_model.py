from prophet import Prophet
import pandas as pd
from prepare_data import load_and_merge_data

def train_prophet(store_id=1, dept_id=1):
    df = load_and_merge_data()

    # Filter for a specific store & department
    df = df[(df["Store"] == store_id) & (df["Dept"] == dept_id)]

    # Rename columns for Prophet
    prophet_df = df[["Date", "Weekly_Sales"]].rename(columns={"Date": "ds", "Weekly_Sales": "y"})

    # Train the model
    model = Prophet()
    model.fit(prophet_df)

    # Forecast 90 days ahead
    future = model.make_future_dataframe(periods=90)
    forecast = model.predict(future)

    return forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail(10)
