from django.shortcuts import render

def home(request):
    books = [
        {'id': 1, 'title': 'The Midnight Library', 'price': 499, 'image': 'https://m.media-amazon.com/images/I/81eA+LfVz5L._SL1500_.jpg'},
        {'id': 2, 'title': 'Ikigai', 'price': 299, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
        {'id': 3, 'title': 'Rich Dad Poor Dad', 'price': 399, 'image': 'https://m.media-amazon.com/images/I/81bsw6fnUiL._SL1500_.jpg'},
        {'id': 4, 'title': 'Deep Work', 'price': 429, 'image': 'https://m.media-amazon.com/images/I/61H0K8C4vZL._SL1500_.jpg'},
        {'id': 5, 'title': 'The Psychology of Money', 'price': 349, 'image': 'https://m.media-amazon.com/images/I/71g2ednj0JL._SL1500_.jpg'},
        {'id': 6, 'title': 'Atomic Habits', 'price': 450, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
    ]
    return render(request, 'store/home.html', {'books': books})

    return render(request, 'store/home.html', {'books': books})
