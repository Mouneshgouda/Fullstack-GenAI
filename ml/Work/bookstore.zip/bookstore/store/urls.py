from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('categories/', views.categories, name='categories'),
    path('contact/', views.contact, name='contact'),
    path('cart/', views.cart, name='cart'),
    
    # ✅ Correct version of the buy path
    path('', views.home, name='home'),
    path('buy/<int:book_id>/', views.buy, name='buy'),
    path('payment/', views.payment, name='payment'),
    path('payment-success/', views.payment_success, name='payment_success'),
]

